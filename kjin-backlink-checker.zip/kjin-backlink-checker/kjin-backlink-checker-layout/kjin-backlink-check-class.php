
<?php
Class backlink_check{

    public $array = array();

    public function get_contents_from_single_url($domain){
        $ch=curl_init();  // cURL started here
        curl_setopt($ch, CURLOPT_URL, $domain);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4 );
        curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt ($ch, CURLOPT_HEADER, true);
        curl_setopt ($ch, CURLOPT_NOBODY, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $curl_result = curl_exec($ch);
        curl_close($ch);
        $dom = new DOMDocument;
        @$dom->loadHTML($curl_result);
        $links = $dom->getElementsByTagName('a');
        return $links;

    }
    public function get_url_section($Total_Url_Array,$url,$links, $Outbound_Url_Array, $Inner_Url_Array, $backlink_count){
//        $links = $Inner_Url_Array;
        foreach($links as $link){
            $temp = $link->getAttribute('href');
            if($temp!="#")
            {
                if (!in_array($temp, $Total_Url_Array))
                {
                    array_push($Total_Url_Array, $temp);
                    //http and https removing section
                    if(strpos($url,'://')!==false){
                        $len =  strpos($url,"//")+2;
                        $url =  substr($url,$len);
                    }
                    //checking new url include typed url
                    if (strpos($temp, $url) === false) {
                        $backlink_count++;
                        $Outbound_Url_Array[$backlink_count - 1] = $temp;
                    }elseif(substr_count($temp,'/')===2)
                    {}
                    else{
                        array_push($Inner_Url_Array,$temp);
                    }
                }
            }
        }

        return [$Total_Url_Array, $Outbound_Url_Array, $Inner_Url_Array, $backlink_count];
    }

    public function empty_array(){
        unset($array);
    }


}
?>