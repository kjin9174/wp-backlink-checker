<?php
//layout page of kjin backlink check plugin
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

include_once("kjin-backlink-check-class.php");

//wordpress hook filter and action testing
//    function filterexample( $example ) {
//        return $example;
//    }
//    add_filter( 'example_filter', 'filterexample' );
//
//    $apply_filter_value = apply_filters( 'example_filter', 'filter me',10,2 );


//wordpress hook filter and action testing

function get_curldata($domain){

    $ch=curl_init();  // cURL started here
    curl_setopt($ch, CURLOPT_URL, $domain);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4 );
    curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
    curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt ($ch, CURLOPT_HEADER, true);
    curl_setopt ($ch, CURLOPT_NOBODY, 0);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    $curl_result = curl_exec($ch);
    curl_close($ch);
    return $curl_result;
}
function get_curlmulti($url_arrays){

    $multi_result = array();
    $link_result_array = array();
    $aURLs = $url_arrays;
    $mh = curl_multi_init(); // init the curl Multi

    $aCurlHandles = array(); // create an array for the individual curl handles

    foreach ($aURLs as $id=>$url) { //add the handles for each url

        $ch = curl_init(); // init curl, and then setup your options
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1); // returns the result - very important
        curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4 );
        curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
        curl_setopt($ch, CURLOPT_HEADER, 0); // no headers in the output

        $aCurlHandles[$url] = $ch;
        curl_multi_add_handle($mh,$ch);
    }

    $active = null;
    //execute the handles
    do {
        $mrc = curl_multi_exec($mh, $active);
    }
    while ($mrc == CURLM_CALL_MULTI_PERFORM);

    while ($active && $mrc == CURLM_OK) {
        if (curl_multi_select($mh) != -1) {
            do {
                $mrc = curl_multi_exec($mh, $active);
            } while ($mrc == CURLM_CALL_MULTI_PERFORM);
        }
    }

    /* This is the relevant bit */
    // iterate through the handles and get your content
    foreach ($aCurlHandles as $url=>$ch) {
        $html = curl_multi_getcontent($ch); // get the content
        array_push($multi_result, $html);
        // do what you want with the HTML
        curl_multi_remove_handle($mh, $ch); // remove the handle (assuming  you are done with it);
    }
    /* End of the relevant bit */

    curl_multi_close($mh); // close the curl multi handler
//    print_r($multi_result);

    return $multi_result;
}

function get_hrefarray_from_html($contents){
    $dom = new DOMDocument;
    @$dom->loadHTML($contents);
    $links = $dom->getElementsByTagName('a');
    return $links;
}
wp_register_style('kjin_backlink_checker', plugins_url('css/style.css',__FILE__ ));
wp_enqueue_style('kjin_backlink_checker');

$my_js_ver  = date("ymd-Gis", filemtime( plugin_dir_path( __FILE__ ) . 'javascript/custom.js' ));
wp_enqueue_script( 'custom_js', plugins_url( 'javascript/custom.js', __FILE__ ), array(), $my_js_ver );

?>

<div class="kjin_backlink_checker_container">
    <div class="kjin_backlink_checker_inputsection">
        <form class="" action="" method="post">
            <input type="text" class="kjin_backlink_checker_input" id="kjin_backlink_checker_input" name="basic_input" required placeholder="Enter URL to check its Backlinks">
            <input type="button" class="kjin_backlink_checker_history" name="basic_history" value="History">
            <input type="submit" class="kjin_backlink_checker_button" name="basic_button" id="kjin_backlink_checker_button" value="Check Now!">
            <input type="hidden" name="action" id="action" value='' />
            <br>

            <a href="https://monitorbacklinks.com/" class="kjin_link">Monitor Backlinks  ›  SEO Tools</a>
        </form>
    </div>
    <hr>
    <div class="kjin_backlink_checker_resultsection">
        <div class="kjin_backlink_checker_result_description">
            <p style="text-align:center">
                We support backlink status of your type URL.
            </p>
            <?php
            echo "First";
            do_action('test');
            add_action('test','echo_func');
            function echo_func(){
                echo "error";
                return "eror";
            }

            echo "End";
            ?>
        </div>
        <?php
        if(isset($_POST['basic_button'])){
            $url = $_POST['basic_input'];
            if(!empty($url)) {
                if (!preg_match('$[https://|http://|ftp://]*.*[.*]$', $url))//filter_var($url, FILTER_VALIDATE_URL) === FALSE)
                {
                    echo "Your typed URL is Invalid URL";
                } else {
                    $my_class = new backlink_check();
//                    get_contents_from_single_url
                    $links = $my_class->get_contents_from_single_url($url);
                    $buffer = $Total_Url_Array = $Outbound_Url_Array = $Inner_Url_Array = array();
                    $backlink_other_count = $backlink_count = 0;

                    $buffer = $my_class->get_url_section($Total_Url_Array, $url, $links, $Outbound_Url_Array, $Inner_Url_Array, $backlink_count);
                    $Total_Url_Array = $buffer[0];
                    $Outbound_Url_Array = $buffer[1];
                    $Inner_Url_Array = $buffer[2];
                    $backlink_count = $buffer[3];
                    $i = 0;


                    if (isset($_POST['action']) && !empty($_POST['action'])) {

//                        $link = reset($Outbound_Url_Array);
//                        array_shift($Outbound_Url_Array);
//                        $url = reset($Outbound_Url_Array);
                        if (isset($Outbound_Url_Array[$i])) {
                            $url = $Outbound_Url_Array[$i];
                            $i++;
                            $links = $my_class->get_contents_from_single_url($url);
                            $my_class->get_url_section($Total_Url_Array, $url, $links, $Outbound_Url_Array, $Inner_Url_Array, $backlink_count);
                        } else {
                            $flag = "false";
                        }

                    }


                }
                $total = temp_link($links, $backlink_count, $Outbound_Url_Array, $url, $Inner_Url_Array, $Total_Url_Array);
                echo "<pre>";
                print_r($total);
                echo "</pre>";
            }
        }
            ?>

