jQuery(function(){
    var a = setInterval("getSuggestions()",1);
});

function getSuggestions(){

    jQuery(document).ready( function(){

        jQuery('#kjin_backlink_checker_button').on('click', function(e) {
            //e.preventDefault();
            var url = jQuery("#kjin_backlink_checker_input").val();

            //process after receiving url

            //process of sending ajax sending
            jQuery.ajax({
                url : '',
                type : 'post',
                data : {
                    action : 'backlinks_checking',
                    i: 1
                       },
                success : function( response ) {
                    //jQuery('.rml_contents').html(response);
                }
            });
            jQuery(this).hide();
        });
    });

}

function progressing_of_responsedata(){

}


