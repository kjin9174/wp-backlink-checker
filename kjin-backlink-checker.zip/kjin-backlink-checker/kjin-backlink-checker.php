<?php
/*
Plugin Name: Kjin Backlink Checker
Plugin URI: http://kkliw2017.com/Jincowboy
Description: A plugin of KJIN Compnay to check Backlink of all URL
Version: 1.0
Shortcode:kjin_backlink_checker_shortcode
Author: Jin of Jincowboy company
Author URI: http://kkliw2017.com/Jincowboy
License: No
*/
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

function backlink_checker_activate() {

    add_option( 'Activated_Plugin', 'Plugin-Slug' );
       /* activation code here */
//    get_template_part('layout');

}
register_activation_hook( __FILE__, 'backlink_checker_activate' );



//function register_script() {
//    //wp_register_script( 'custom_jquery', plugins_url('/js/custom-jquery.js', __FILE__), array('jquery'), '2.5.1' );
//
//    wp_register_style( 'style', plugins_url('css/style.css', __FILE__));
//}
//add_action('init', 'register_script');
//function load_backlink_checker() {
//
//    if ( is_admin() && get_option( 'Activated_Plugin' ) == 'Plugin-Slug' ) {
//
//        delete_option( 'Activated_Plugin' );
//        /* do stuff once right after activation */
//        // example: add_action( 'init', 'my_init_function' );
//    }
//
//}
//add_action( 'admin_init', 'load_backlink_checker' );

function kjin_backlink_checker_inputsection(){
    include('kjin-backlink-checker-layout/kjin-backlink-checker-layout.php');
}
add_shortcode( 'kjin_backlink_checker_shortcode', 'kjin_backlink_checker_inputsection' );

function deal_action(){

}

?>